def lower_lvl():
    print('Lower ground')