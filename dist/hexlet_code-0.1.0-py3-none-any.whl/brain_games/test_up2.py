from scripts.games.test import lower_lvl
from scripts.test_up1 import middle_lvl


def upper_lvl():
    print('I have a higround')


lower_lvl()
middle_lvl()
upper_lvl()