import random

from brain_games.scripts.engine import game_body
from brain_games.games import brain_calc_game


def calc():
    number1 = random.randint(0, 20)
    number2 = random.randint(0, 10)
    options = '+', '-', '*'
    operator = random.choice(options)
    # через ф-строки
    question = str(number1) + ' ' + operator + ' ' + str(number2)
    if operator == '+':
        true_answer = number1 + number2
    elif operator == '-':
        true_answer = number1 - number2
    else:
        true_answer = number1 * number2
    return question, true_answer


def main():
    condition = 'What is the result of the expression?'
    input_type = 'integer'
    print('DECS: ', brain_calc_game.DEDCRIPTION)
    game_body(condition, input_type, calc)


if __name__ == '__main__':
    main()
