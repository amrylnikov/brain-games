from test_up2 import upper_lvl
import double_test.test_far_away


def middle_lvl():
    print('I\'ll hold middle ground')

double_test.test_far_away.faraway_lvl()
upper_lvl()