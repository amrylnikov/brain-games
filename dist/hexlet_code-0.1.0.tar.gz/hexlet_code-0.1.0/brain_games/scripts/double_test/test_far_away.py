def faraway_lvl():
    print('is it gonna work?')